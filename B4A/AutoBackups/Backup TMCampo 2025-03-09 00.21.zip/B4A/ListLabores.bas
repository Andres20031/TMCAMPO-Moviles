﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13
@EndOfDesignText@
Sub Class_Globals
	Private Root As B4XView 'ignore
	Private xui As XUI 'ignore
	Private utilClass As util
	Dim xui As XUI
	Private GifViewerLoading As GifViewer
	Private CLV_Labores As CustomListView
	Private const rdcLink As String = "http://84.46.255.129:17178/rdc"
	Dim sf As StringFunctions
	Private LabelLabores As Label
	Private ButtonGrabar As Button
	Private ButtonCancelar As Button
	Private ButtonAplazar As Button
End Sub

'You can add more parameters here.
Public Sub Initialize As Object
	Return Me
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	utilClass.Initialize
	utilClass.SetStatusBarColor(Colors.White,Colors.White)
	
	Root.LoadLayout("ListPerson")
	GifViewerLoading.SetGif(File.DirAssets,"carga.gif")
	
	
End Sub

Sub B4XPage_Appear
	
	CLV_Labores.Clear
	GifViewerLoading.Start
	CLV_Labores.Add(CreateItem(0,"1220","Cavi","La Floresta","03B","12.23","Fertilización mecanica","2025/03/01","3","Ninguna"),0)
	CLV_Labores.Add(CreateItem(1,"1221","Cavi","La Llanura","24","12.23","Subsuelo","2025/03/01","5","Cuidado"),1)
	GifViewerLoading.Stop
'	' Inicializo la base de datos en un hilo de fondo
'	Dim Req As DBRequestManager
'	Req.Initialize(Me, rdcLink & "?DBName=" & Main.pDBName)
'	Dim cmd As DBCommand = CreateCommand("", Null)
'	
'	' Realiza la consulta de manera asíncrona
'	Wait For (Req.ExecuteQuery(cmd, 0, Null)) JobDone(j As HttpJob)
'
'	' Manejo de la respuesta
'	If j.Success Then
'		sf.Initialize
'		Req.HandleJobAsync(j, "req")
'
'		Wait For (Req) req_Result(res As DBResult)
'
'		' Iteramos sobre los resultados y agregamos cada persona a la CLV
'		For Each row() As Object In res.Rows
'			
'		Next
'        
'		GifViewerLoading.Stop
'	Else
'		Log("ERROR: " & j.ErrorMessage)
'	End If
	
End Sub

Private Sub CreateItem(position As Int, Consecutivo As String, Nit As String, Hacienda As String, Suerte As String, Area As String, Labor As String, FechaPro As String, Retraso As String,Observacion As String) As Panel
	' Crea un nuevo panel con el objeto B4XView del kit de herramientas XUI
	Dim panel As B4XView = xui.CreatePanel("")
	panel.SetLayoutAnimated(1, 0, 0, 100%X, 130dip)
	
	' Carga el diseño previamente definido llamado "Cardp" en el panel creado
	panel.LoadLayout("CardLabores")
	Dim cs As CSBuilder
	cs.Initialize
	
	' Agrega el texto "Consecutivo: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Consecutivo: ").Pop.Color(Colors.Gray).Append(Consecutivo & CRLF).Pop
	' Agrega el texto "Nit: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Nit: ").Pop.Color(Colors.Gray).Append(Nit & CRLF).Pop
	' Agrega el texto "Hacienda: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Hacienda: ").Pop.Color(Colors.Gray).Append(Hacienda & CRLF).Pop
	' Agrega el texto "Suerte: y Area: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Suerte: ").Pop.Color(Colors.Gray).Append(Suerte & CRLF).Pop.Append("  ").Pop.Bold.Color(Colors.Black).Append("Area: ").Pop.Color(Colors.Gray).Append(Area & CRLF).Pop
	' Agrega el texto "Labor: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Labor: ").Pop.Color(Colors.Gray).Append(Labor & CRLF).Pop
	' Agrega el texto "Fecha programa: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Fecha programa: ").Pop.Color(Colors.Gray).Append(FechaPro & CRLF).Pop
	' Agrega el texto "Días atraso: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Días atraso: ").Pop.Color(Colors.Gray).Append(Retraso & CRLF).Pop
	' Agrega el texto "Observación: " en negrita y negro, seguido de la fecha en gris y sin negrita
	cs.Bold.Color(Colors.Black).Append("Observación: ").Pop.Color(Colors.Gray).Append(Observacion & CRLF).Pop
	
	LabelLabores.Text = cs
	
	ButtonGrabar.Tag = Consecutivo
	ButtonCancelar.Tag = Consecutivo
	ButtonAplazar.Tag = Consecutivo
End Sub

Sub CreateCommand(Name As String, Parameters() As Object) As DBCommand
	Dim cmd As DBCommand
	cmd.Initialize
	cmd.Name = Name
	If Parameters <> Null Then cmd.Parameters = Parameters
	Return cmd
End Sub

'You can see the list of page related events in the B4XPagesManager object. The event name is B4XPage.

Private Sub ButtonGrabar_Click
	
End Sub

Private Sub ButtonCancelar_Click
	
End Sub

Private Sub ButtonAplazar_Click
	
End Sub
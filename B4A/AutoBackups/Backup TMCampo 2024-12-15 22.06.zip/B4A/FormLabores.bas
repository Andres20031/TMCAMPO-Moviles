﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13
@EndOfDesignText@
Sub Class_Globals
	Private Root As B4XView 'ignore
	Private xui As XUI 'ignore
	Private utilClass As util
	Private CustomListView1Geral As CustomListView
	Private Panel1geral As Panel
	Private Label13Time As Label
	Private Label14Time As Label
	Private Panel3 As Panel
	Private Panel12 As Panel
	Private const rdcLink As String = "http://84.46.255.129:17178/rdc"
	Dim fechaInicio As String
	Dim fechaFin As String
	

	Private SD_xComboBoxNit As SD_xComboBox
	Private SD_xComboBoxHacienda As SD_xComboBox
	Private SD_xComboBoxLote As SD_xComboBox
	Private SD_xComboBoxLabor As SD_xComboBox
	Private SD_xComboBoxElemento As SD_xComboBox
	Private SD_xComboBoxTypeForm As SD_xComboBox
	Dim haciendaCBX As String
	Dim nitEmpresaCBX As String
	
End Sub

'You can add more parameters here.
Public Sub Initialize As Object
	Return Me
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	'load the layout to Root
	
End Sub

Private Sub B4XPage_Appear
	utilClass.Initialize
	utilClass.SetStatusBarColor(Colors.White,0xB4008000)
	Root.LoadLayout("form")
	CustomListView1Geral.DefaultTextBackgroundColor=0xFF25253D
	CustomListView1Geral.DefaultTextColor=Colors.White
	CustomListView1Geral.Add(CreateItem,"form1")
	
	Dim Req As DBRequestManager
	Req.Initialize(Me, rdcLink & "?DBName=" & Main.pDBName)
	
	'CONSULTAR NIT'
	Dim cmd As DBCommand = CreateCommand("select_nit", Null)
	Wait For (Req.ExecuteQuery(cmd, 0, Null)) JobDone(j As HttpJob)
	If j.Success Then
		Req.HandleJobAsync(j, "req")
		Wait For (Req) req_Result(res As DBResult)
		For Each row() As Object In res.Rows
			Dim razonSocial As String = row(0)
			Dim nit As String = row(1)
			SD_xComboBoxNit.Add(razonSocial & " - " & nit, nit)
		Next
	Else
		Log("Error en la consulta de NITs: " & j.ErrorMessage)
	End If
	'FIN CONSULTAR NIT'
	
	'CONSULTAR LABOR'
	Dim cmdLaborMaquina As DBCommand = CreateCommand("select_labor_maq", Null)
	Wait For (Req.ExecuteQuery(cmdLaborMaquina, 0, Null)) JobDone(j3 As HttpJob)
	If j3.Success Then
		Req.HandleJobAsync(j3, "req_labormaquina")
		Wait For (Req) req_labormaquina_Result(resLaborMaquina As DBResult)
		For Each rowLaborMaquina() As Object In resLaborMaquina.Rows
			Dim codigoLaborMaquina As String = rowLaborMaquina(0) ' Cdgo_Dstno
			Dim descripcionLaborMaquina As String = rowLaborMaquina(1) ' Dscrpcion_Dstno
			SD_xComboBoxLabor.Add(descripcionLaborMaquina & " - " & codigoLaborMaquina, codigoLaborMaquina)
		Next
	Else
		Log("Error en la consulta de Maquina: " & j3.ErrorMessage)
	End If
	j3.Release
	'FIN CONSULTAR LABOR'
	
	
	
	'AGREGAR AL SELECT TIPO DE FORMULARIO'
	SD_xComboBoxTypeForm.Add("Insumo",0)
	SD_xComboBoxTypeForm.Add("Siembra",1)
	SD_xComboBoxTypeForm.Add("Riego",2)
End Sub



Private Sub CreateItem As Panel
	' Crea un nuevo panel con el objeto B4XView del kit de herramientas XUI
	Dim panel As B4XView = xui.CreatePanel("")
	panel.SetLayoutAnimated(1, 0, 0, 100%X, 500dip)
    
	' Carga el diseño previamente definido llamado "addMaquinariaUI" en el panel creado
	panel.LoadLayout("addLaboresUI")
	
	panel.Height=Panel1geral.Height
	
	Return panel
End Sub
'You can see the list of page related events in the B4XPagesManager object. The event name is B4XPage.

Private Sub Label13Time_Click
	Panel12.Visible = True
End Sub

Private Sub Label14Time_Click
	Panel3.Visible = True
End Sub

Private Sub AS_DatePicker1_SelectedDateChanged(Date As Long)
	' Obtener la fecha seleccionada
	Dim formattedDate As String = DateTime.Date(Date)
    
	' Reemplazar cualquier '/' por '-' en caso de que la fecha sea en formato con '/'
	formattedDate = formattedDate.Replace("/", "-")
    
	' Agregar la parte de la hora
	formattedDate = formattedDate & " 00:00:00"
    
	' Mostrar la fecha formateada en el Label
	Label13Time.Text = formattedDate
    
	' Hacer invisible el Panel
	Panel12.Visible = False
    
	' Obtener la fecha y guardarla en la variable fecha
	fechaInicio = formattedDate
    
	' Log para verificar el valor de la fecha
End Sub

Private Sub AS_DatePicker2_SelectedDateChanged(Date As Long)
	' Obtener la fecha seleccionada
	Dim formattedDate As String = DateTime.Date(Date)
    
	' Reemplazar cualquier '/' por '-' en caso de que la fecha sea en formato con '/'
	formattedDate = formattedDate.Replace("/", "-")
    
	' Agregar la parte de la hora
	formattedDate = formattedDate & " 00:00:00"
    
	' Mostrar la fecha formateada en el Label
	Label14Time.Text = formattedDate
    
	' Hacer invisible el Panel
	Panel3.Visible = False
    
	' Obtener la fecha y guardarla en la variable fecha
	fechaFin = formattedDate
    
	' Log para verificar el valor de la fecha
End Sub

Sub CreateCommand(Name As String, Parameters() As Object) As DBCommand
	Dim cmd As DBCommand
	cmd.Initialize
	cmd.Name = Name
	If Parameters <> Null Then cmd.Parameters = Parameters
	Return cmd
End Sub

Private Sub SD_xComboBoxNit_ItemClick (Position As Int, Value As Object)
	nitEmpresaCBX=Value
	
	Dim Req As DBRequestManager
	Req.Initialize(Me, rdcLink & "?DBName=" & Main.pDBName)
	Dim cmd As DBCommand = CreateCommand("select_haciendas", Array("N"))

	' Ejecuta la consulta
	Wait For (Req.ExecuteQuery(cmd, 0, Null)) JobDone(j As HttpJob)

	' Verificar si la consulta fue exitosa
	If j.Success Then
		' Maneja el resultado de la consulta
		Req.HandleJobAsync(j, "req")
		Wait For (Req) req_Result(res As DBResult)

    
		' Llenar el ComboBox con NITs y razones sociales
		For Each row() As Object In res.Rows
			Dim Codg_Hacienda As String = row(0)
			Dim NombreHacienda As String = row(1)
        
			' Agregar la información al ComboBox (ajusta según el formato requerido)
			SD_xComboBoxHacienda.Add(NombreHacienda & " - " & Codg_Hacienda, Codg_Hacienda)
		Next
    
	Else
		' Si hay un error, muestra el mensaje
		Log("Error: " & j.ErrorMessage)
	End If
	' Libera el trabajo HTTP
	j.Release
	' FIN DE LA CONSULTA DE LOS NITS
End Sub

Private Sub SD_xComboBoxHacienda_ItemClick (Position As Int, Value As Object)
	haciendaCBX=Value
	
	SD_xComboBoxLote.Clear
	Dim Req As DBRequestManager
	Req.Initialize(Me, rdcLink & "?DBName=" & Main.pDBName)
	Dim cmd As DBCommand = CreateCommand("select_lotes", Array(nitEmpresaCBX,haciendaCBX))

	' Ejecuta la consulta
	Wait For (Req.ExecuteQuery(cmd, 0, Null)) JobDone(j As HttpJob)

	' Verificar si la consulta fue exitosa
	If j.Success Then
		' Maneja el resultado de la consulta
		Req.HandleJobAsync(j, "req")
		Wait For (Req) req_Result(res As DBResult)

    
		' Llenar el ComboBox con NITs y razones sociales
		For Each row() As Object In res.Rows
			Dim Codg_Hacienda As String = row(0)
        
			' Agregar la información al ComboBox (ajusta según el formato requerido)
			SD_xComboBoxLote.Add("Codigo: "&Codg_Hacienda, Codg_Hacienda)
		Next
    
	Else
		' Si hay un error, muestra el mensaje
		Log("Error: " & j.ErrorMessage)
	End If

	' Libera el trabajo HTTP
	j.Release
	' FIN DE LA CONSULTA DE LOS NITS
End Sub

Private Sub SD_xComboBoxLote_ItemClick (Position As Int, Value As Object)
	
End Sub

Private Sub SD_xComboBoxLabor_ItemClick (Position As Int, Value As Object)
	
End Sub

Private Sub SD_xComboBoxElemento_ItemClick (Position As Int, Value As Object)
	
End Sub

Private Sub SD_xComboBoxTypeForm_ItemClick (Position As Int, Value As Object)
	
End Sub
﻿B4A=true
Group=Default Group
ModulesStructureVersion=1
Type=Class
Version=13
@EndOfDesignText@
Sub Class_Globals
	Private Root As B4XView 'ignore
	Private xui As XUI 'ignore
	Private utilClass As util
	Private const rdcLink As String = "http://84.46.255.129:17178/rdc"
	Private Label3 As Label
	Private CustomListView1Geral As CustomListView
	Private Panel1geral As Panel
	Private Label13Time As Label
	Private SD_xComboBoxPluviometro As SD_xComboBox
	Private EditTextHoraFin As EditText
	Private Panel12 As Panel
	Private AS_DatePicker1 As AS_DatePicker
	Dim fecha As String
End Sub

'You can add more parameters here.
Public Sub Initialize As Object
	Return Me
End Sub

'This event will be called once, before the page becomes visible.
Private Sub B4XPage_Created (Root1 As B4XView)
	Root = Root1
	'load the layout to Root
	
End Sub

Private Sub B4XPage_Appear
	utilClass.Initialize
	utilClass.SetStatusBarColor(Colors.White,0xB4008000)
	Root.LoadLayout("form")
	CustomListView1Geral.DefaultTextBackgroundColor=0xFF25253D
	CustomListView1Geral.DefaultTextColor=Colors.White
	CustomListView1Geral.Add(CreateItem,"formPreci")
	
	Dim Req As DBRequestManager
	Req.Initialize(Me, rdcLink & "?DBName=" & Main.pDBName)
	
	'CONSULTAR MAQUINA'
	Dim cmdPluviometro As DBCommand = CreateCommand("select_maquina_pluviometros", Null)
	Wait For (Req.ExecuteQuery(cmdPluviometro, 0, Null)) JobDone(j2 As HttpJob)
	If j2.Success Then
		Req.HandleJobAsync(j2, "req_pluviometro")
		Wait For (Req) req_pluviometro_Result(resPluviometro As DBResult)
		For Each rowPluviometro() As Object In resPluviometro.Rows
			Dim cdgo_Plvmtro As String = rowPluviometro(0) '
			Dim Nombre_Plvmtro As String = rowPluviometro(1) '
			SD_xComboBoxPluviometro.Add(cdgo_Plvmtro&" - "&Nombre_Plvmtro,cdgo_Plvmtro)
		Next
	Else
		Log("Error en la consulta de Maquina: " & j2.ErrorMessage)
	End If
	j2.Release
	
End Sub


Private Sub CreateItem As Panel
	' Crea un nuevo panel con el objeto B4XView del kit de herramientas XUI
	Dim panel As B4XView = xui.CreatePanel("")
	panel.SetLayoutAnimated(1, 0, 0, 100%X, 92%Y)
	' Carga el diseño previamente definido llamado "" en el panel creado
	panel.LoadLayout("addPrecipitacionUI")
	panel.Height=Panel1geral.Height
	
	Return panel
End Sub
'You can see the list of page related events in the B4XPagesManager object. The event name is B4XPage.
Sub CreateCommand(Name As String, Parameters() As Object) As DBCommand
	Dim cmd As DBCommand
	cmd.Initialize
	cmd.Name = Name
	If Parameters <> Null Then cmd.Parameters = Parameters
	Return cmd
End Sub


Private Sub Label1Back_Click
	
End Sub

Private Sub Label2Save_Click
	
End Sub

Private Sub Label13Time_Click
	Panel12.Visible = True
End Sub

Private Sub SD_xComboBoxPluviometro_ItemClick (Position As Int, Value As Object)
	Log("VALOR COMBOBOX: "&Value)
End Sub

Private Sub AS_DatePicker1_SelectedDateChanged(Date As Long)
	' Obtener la fecha seleccionada
	Dim formattedDate As String = DateTime.Date(Date)
    
	' Reemplazar cualquier '/' por '-' en caso de que la fecha sea en formato con '/'
	formattedDate = formattedDate.Replace("/", "-")
    
	' Agregar la parte de la hora
	formattedDate = formattedDate & " 00:00:00"
    
	' Mostrar la fecha formateada en el Label
	Label13Time.Text = formattedDate
    
	' Hacer invisible el Panel
	Panel12.Visible = False
    
	' Obtener la fecha y guardarla en la variable fecha
	fecha = formattedDate
    
	' Log para verificar el valor de la fecha
	Log(fecha)
End Sub

Private Sub EditTextHoraFin_TextChanged (Old As String, New As String)
	Log("Texto anterior: " & Old)
	Log("Texto nuevo: " & New)
    
	' Puedes guardar el texto nuevo en una variable
	Dim textoCapturado As String = New
    
	' Realizar acciones con el texto capturado
	If textoCapturado.Length > 5 Then
		Log("El texto es mayor de 5 caracteres: " & textoCapturado)
	End If
End Sub